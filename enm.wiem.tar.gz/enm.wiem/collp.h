
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

SDL_Color GetPixel(SDL_Surface *background_mask,int x,int y);
int detecter_collision_background (SDL_Surface *image, SDL_Rect position,SDL_Surface *background_mask);

#end
